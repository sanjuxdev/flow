# Build Flow APK using only your phone

This workflow uses GitHub Actions' hosted Linux runner to compile Flow, so you do not need a PC. It is a build path, not a prebuilt APK; the APK exists only if the cloud build succeeds.

## Steps

1. In your phone browser, sign in to GitHub and create a new repository named `flow`.
2. Extract `Flow-Source.zip` using your phone's file manager.
3. Upload the extracted project files and folders into the repository's `main` branch. Include the hidden `.github/workflows/android-apk.yml` file. If your file manager hides dot-folders, create `.github/workflows` in GitHub's web editor and add `android-apk.yml` using the contents from that file.
4. Open the repository's **Actions** tab and select **Build Flow APK**. If it is not listed, open the workflow file in the repository and commit it to `main`.
5. Open the latest workflow run. Wait for all steps to finish successfully.
6. At the bottom of the run page, under **Artifacts**, tap `Flow-debug-APK` to download the ZIP artifact.
7. Extract that artifact on your phone; it contains `app-debug.apk`. Tap the APK and allow installs from your browser/file manager if Android asks.

## Important

- A successful cloud build is not guaranteed: dependency or Android compiler errors may need fixes.
- The workflow runs Flutter tests before packaging; if tests fail, no APK artifact will be uploaded.
- This is a debug APK, suitable for personal testing, not a signed release for Play Store distribution.
- Android may offer home screen, lock screen, or both when setting a live wallpaper, depending on the device.
- The wallpaper has not been physically tested on a device yet.

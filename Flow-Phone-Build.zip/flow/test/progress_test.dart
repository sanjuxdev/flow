import 'package:flutter_test/flutter_test.dart';
import 'package:flow/main.dart';

void main() {
  test('empty list is neutral', () => expect(stateFor(0, 0), FlowState.neutral));
  test('below 34 percent is red', () {
    expect(stateFor(0, 5), FlowState.red);
    expect(stateFor(1, 5), FlowState.red);
  });
  test('34 percent and above but incomplete is yellow', () {
    expect(stateFor(2, 5), FlowState.yellow);
    expect(stateFor(4, 5), FlowState.yellow);
  });
  test('all tasks complete is green', () => expect(stateFor(5, 5), FlowState.green));
}

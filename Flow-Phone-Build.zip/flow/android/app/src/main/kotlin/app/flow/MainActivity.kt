package app.flow

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.util.AtomicFile
import app.flow.wallpaper.FlowWallpaperService
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class MainActivity : FlutterActivity() {
    private val channel = "app.flow/wallpaper"
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channel).setMethodCallHandler { call, result ->
            when (call.method) {
                "publishSnapshot" -> {
                    try {
                        val raw = call.argument<String>("json") ?: error("Missing snapshot")
                        val obj = JSONObject(raw)
                        require(obj.optInt("schemaVersion") == 1) { "Unsupported snapshot schema" }
                        val tasks = obj.optJSONArray("tasks") ?: error("Missing tasks")
                        require(tasks.length() <= 500) { "Too many tasks" }
                        val target = File(filesDir, "flow-wallpaper.json")
                        val atomic = AtomicFile(target)
                        var stream: FileOutputStream? = null
                        try {
                            stream = atomic.startWrite()
                            stream.write(raw.toByteArray(Charsets.UTF_8))
                            stream.fd.sync()
                            atomic.finishWrite(stream)
                        } catch (t: Throwable) {
                            if (stream != null) atomic.failWrite(stream)
                            throw t
                        }
                        FlowWallpaperService.notifySnapshotChanged(applicationContext)
                        result.success(true)
                    } catch (t: Throwable) { result.error("SNAPSHOT_WRITE_FAILED", t.message, null) }
                }
                "openWallpaperPicker" -> {
                    try {
                        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                            putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, ComponentName(this@MainActivity, FlowWallpaperService::class.java))
                        }
                        startActivity(intent)
                        result.success(true)
                    } catch (t: Throwable) { result.error("WALLPAPER_PICKER_FAILED", t.message, null) }
                }
                else -> result.notImplemented()
            }
        }
    }
}

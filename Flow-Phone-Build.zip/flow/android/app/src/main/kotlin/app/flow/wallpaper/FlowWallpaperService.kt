package app.flow.wallpaper

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.util.AtomicFile
import android.view.SurfaceHolder
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CopyOnWriteArraySet

data class WallpaperTask(val title: String, val completed: Boolean)
data class WallpaperSnapshot(val revision: Long, val date: String, val tasks: List<WallpaperTask>, val done: Int, val total: Int, val state: String) {
    companion object {
        fun parse(raw: String): WallpaperSnapshot {
            val j = JSONObject(raw)
            require(j.optInt("schemaVersion") == 1) { "Unsupported schema" }
            val arr = j.getJSONArray("tasks")
            require(arr.length() <= 500) { "Snapshot task limit exceeded" }
            val tasks = (0 until arr.length()).map { i ->
                val t = arr.getJSONObject(i)
                val title = t.optString("title", "").take(500)
                WallpaperTask(title, t.optBoolean("completed", false))
            }
            val done = tasks.count { it.completed }; val total = tasks.size
            val expected = when { total == 0 -> "neutral"; done == total -> "green"; done.toDouble()/total < .34 -> "red"; else -> "yellow" }
            val declared = j.optString("colorState", expected)
            require(declared == expected) { "Inconsistent progress state" }
            return WallpaperSnapshot(j.optLong("revision"), j.optString("localDate"), tasks, done, total, expected)
        }
    }
}

class FlowWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = FlowEngine()
    inner class FlowEngine : Engine() {
        private val main = Handler(Looper.getMainLooper())
        private var visible = false
        private var snapshot = WallpaperSnapshot(0, "", emptyList(), 0, 0, "neutral")
        private val drawRunnable = Runnable { drawFrame() }
        private val listener: () -> Unit = { main.post { loadSnapshot(); drawFrame() } }
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val bounds = Rect()
        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            engines.add(listener)
            loadSnapshot()
        }
        override fun onVisibilityChanged(visibleNow: Boolean) {
            visible = visibleNow
            if (visible) { loadSnapshot(); drawFrame() } else main.removeCallbacks(drawRunnable)
        }
        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            if (visible) drawFrame()
        }
        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false; main.removeCallbacks(drawRunnable)
            super.onSurfaceDestroyed(holder)
        }
        override fun onDestroy() {
            engines.remove(listener); main.removeCallbacks(drawRunnable)
            super.onDestroy()
        }
        private fun loadSnapshot() {
            try {
                val f = File(applicationContext.filesDir, "flow-wallpaper.json")
                if (!f.exists()) return
                val parsed = WallpaperSnapshot.parse(AtomicFile(f).openRead().bufferedReader().use { it.readText() })
                if (parsed.revision >= snapshot.revision) snapshot = parsed
            } catch (_: Exception) { /* Keep last valid snapshot on malformed or partial state. */ }
        }
        private fun drawFrame() {
            if (!visible) return
            var canvas: Canvas? = null
            try {
                canvas = surfaceHolder.lockCanvas()
                if (canvas != null) render(canvas, snapshot)
            } catch (_: Exception) {
            } finally {
                if (canvas != null) try { surfaceHolder.unlockCanvasAndPost(canvas) } catch (_: Exception) {}
            }
        }
        private fun render(c: Canvas, s: WallpaperSnapshot) {
            val w = c.width.toFloat(); val h = c.height.toFloat()
            val stateColor = when (s.state) { "red" -> Color.rgb(255,83,100); "yellow" -> Color.rgb(255,200,87); "green" -> Color.rgb(131,227,119); else -> Color.rgb(124,132,148) }
            c.drawColor(Color.rgb(15,17,22))
            paint.style = Paint.Style.FILL; paint.color = Color.rgb(25,29,37); c.drawCircle(w*.85f, h*.2f, w*.52f, paint)
            paint.color = stateColor; paint.alpha = 24; c.drawCircle(w*.12f, h*.74f, w*.43f, paint); paint.alpha = 255
            paint.color = Color.WHITE; paint.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL); paint.textSize = w*.17f
            c.drawText(java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date()), w*.08f, h*.19f, paint)
            paint.textSize = w*.035f; paint.color = 0xFFB8BEC9.toInt()
            c.drawText(java.text.SimpleDateFormat("EEEE, d MMMM", java.util.Locale.getDefault()).format(java.util.Date()).uppercase(), w*.085f, h*.235f, paint)
            paint.color = stateColor; paint.typeface = Typeface.create("sans-serif", Typeface.BOLD); paint.textSize = w*.033f
            c.drawText("FLOW  /  DAILY FOCUS", w*.085f, h*.40f, paint)
            paint.color = Color.WHITE; paint.textSize = w*.065f
            c.drawText("${s.done} OF ${s.total} TASKS", w*.085f, h*.455f, paint)
            val left=w*.085f; val right=w*.915f; val barY=h*.485f
            paint.color = 0xFF343944.toInt(); c.drawRoundRect(left,barY,right,barY+w*.012f,w*.01f,w*.01f,paint)
            paint.color = stateColor; if (s.total > 0) c.drawRoundRect(left,barY,left+(right-left)*s.done/s.total,barY+w*.012f,w*.01f,w*.01f,paint)
            val shown=s.tasks.take(7); val rowH=h*.052f
            shown.forEachIndexed { i,t ->
                val y=h*.555f+i*rowH
                paint.style=Paint.Style.STROKE; paint.strokeWidth=w*.004f; paint.color=if(t.completed) stateColor else 0xFF858B98.toInt()
                c.drawRoundRect(left,y-w*.028f,left+w*.035f,y+w*.007f,w*.006f,w*.006f,paint)
                if(t.completed) { paint.style=Paint.Style.STROKE; paint.strokeWidth=w*.004f; c.drawLine(left+w*.007f,y-w*.009f,left+w*.015f,y,paint); c.drawLine(left+w*.015f,y,left+w*.029f,y-w*.019f,paint) }
                paint.style=Paint.Style.FILL; paint.color=if(t.completed) 0xFF9298A3.toInt() else Color.WHITE; paint.textSize=w*.038f; paint.typeface=Typeface.create("sans-serif",Typeface.NORMAL)
                var title=t.title
                val maxW=right-(left+w*.055f)
                while(title.isNotEmpty() && paint.measureText(title)>maxW) title=title.dropLast(1)
                if(title != t.title && title.length>2) title=title.dropLast(1)+"…"
                c.drawText(title,left+w*.055f,y,paint)
            }
            if(s.tasks.size>shown.size) { paint.color=0xFF9AA1AE.toInt(); paint.textSize=w*.033f; c.drawText("+${s.tasks.size-shown.size} MORE",left,h*.555f+shown.size*rowH,paint) }
            paint.color=stateColor; paint.textSize=w*.029f; paint.typeface=Typeface.create("sans-serif-medium",Typeface.BOLD)
            val msg=when(s.state) { "green" -> "YOU SHOWED UP. WELL DONE."; "neutral" -> "ADD A TASK. START SMALL."; "yellow" -> "KEEP YOUR MOMENTUM."; else -> "ONE THING AT A TIME." }
            c.drawText(msg,left,h*.94f,paint)
        }
    }
    companion object {
        private val engines = CopyOnWriteArraySet<() -> Unit>()
        fun notifySnapshotChanged(context: Context) { engines.forEach { it.invoke() } }
    }
}

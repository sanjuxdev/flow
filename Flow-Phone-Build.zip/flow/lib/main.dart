import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;

const bridge = MethodChannel('app.flow/wallpaper');
const bg = Color(0xFF101216);
const panel = Color(0xFF1A1D24);
const accent = Color(0xFFB8F36B);

enum FlowState { neutral, red, yellow, green }

class FlowTask {
  final int? id;
  final String title;
  final bool done;
  final int position;
  const FlowTask({this.id, required this.title, this.done = false, this.position = 0});
  FlowTask copyWith({int? id, String? title, bool? done, int? position}) =>
      FlowTask(id: id ?? this.id, title: title ?? this.title, done: done ?? this.done, position: position ?? this.position);
  Map<String, Object?> toMap() => {'id': id, 'title': title, 'done': done ? 1 : 0, 'position': position, 'day': DateFormat('yyyy-MM-dd').format(DateTime.now())};
  factory FlowTask.fromMap(Map<String, Object?> m) => FlowTask(id: m['id'] as int, title: m['title'] as String, done: (m['done'] as int) == 1, position: m['position'] as int);
}

FlowState stateFor(int done, int total) {
  if (total == 0) return FlowState.neutral;
  final pct = done / total;
  if (done == total) return FlowState.green;
  if (pct < .34) return FlowState.red;
  return FlowState.yellow;
}
Color colorFor(FlowState s) => switch (s) {
  FlowState.red => const Color(0xFFFF5364),
  FlowState.yellow => const Color(0xFFFFC857),
  FlowState.green => const Color(0xFF83E377),
  FlowState.neutral => const Color(0xFF7C8494),
};

class TaskStore {
  Database? _db;
  Future<Database> get db async => _db ??= await openDatabase(
    p.join(await getDatabasesPath(), 'flow.db'), version: 1,
    onCreate: (d, _) async {
      await d.execute('CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 0, position INTEGER NOT NULL, day TEXT NOT NULL)');
      await d.execute('CREATE TABLE history(day TEXT PRIMARY KEY, completed INTEGER NOT NULL, total INTEGER NOT NULL)');
    });
  String get today => DateFormat('yyyy-MM-dd').format(DateTime.now());
  Future<List<FlowTask>> all() async {
    final rows = await (await db).query('tasks', where: 'day=?', whereArgs: [today], orderBy: 'position ASC, id ASC');
    return rows.map(FlowTask.fromMap).toList();
  }
  Future<void> add(String title) async {
    final d = await db; final list = await all();
    await d.insert('tasks', {'title': title.trim(), 'done': 0, 'position': list.length, 'day': today});
  }
  Future<void> update(FlowTask task, String title) async => (await db).update('tasks', {'title': title.trim()}, where: 'id=?', whereArgs: [task.id]);
  Future<void> toggle(FlowTask t) async => (await db).update('tasks', {'done': t.done ? 0 : 1}, where: 'id=?', whereArgs: [t.id]);
  Future<void> delete(FlowTask t) async => (await db).delete('tasks', where: 'id=?', whereArgs: [t.id]);
  Future<void> reorder(List<FlowTask> tasks) async {
    final d = await db;
    await d.transaction((txn) async { for (var i=0;i<tasks.length;i++) { await txn.update('tasks', {'position': i}, where: 'id=?', whereArgs: [tasks[i].id]); }});
  }
  Future<void> saveHistory(List<FlowTask> tasks) async {
    final done = tasks.where((t) => t.done).length;
    await (await db).insert('history', {'day': today, 'completed': done, 'total': tasks.length}, conflictAlgorithm: ConflictAlgorithm.replace);
  }
}

final storeProvider = Provider((_) => TaskStore());
final tasksProvider = FutureProvider<List<FlowTask>>((ref) => ref.watch(storeProvider).all());

Future<void> publish(List<FlowTask> tasks) async {
  final done = tasks.where((t) => t.done).length;
  final s = stateFor(done, tasks.length);
  final snapshot = {
    'schemaVersion': 1, 'revision': DateTime.now().microsecondsSinceEpoch,
    'localDate': DateFormat('yyyy-MM-dd').format(DateTime.now()),
    'tasks': tasks.map((t) => {'id': '${t.id}', 'title': t.title, 'completed': t.done}).toList(),
    'completedCount': done, 'totalCount': tasks.length,
    'completionPercent': tasks.isEmpty ? 0 : (done * 100 / tasks.length).round(),
    'colorState': s.name, 'updatedAt': DateTime.now().toIso8601String(),
  };
  try { await bridge.invokeMethod('publishSnapshot', {'json': jsonEncode(snapshot)}); } on PlatformException { /* DB remains authoritative; next app start retries. */ }
}

void main() => runApp(const ProviderScope(child: FlowApp()));

class FlowApp extends StatelessWidget {
  const FlowApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    title: 'Flow', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, brightness: Brightness.dark, scaffoldBackgroundColor: bg, colorScheme: ColorScheme.fromSeed(seedColor: accent, brightness: Brightness.dark), fontFamily: 'Roboto'),
    home: const Dashboard());
}

class Dashboard extends ConsumerStatefulWidget {
  const Dashboard({super.key});
  @override ConsumerState<Dashboard> createState() => _DashboardState();
}
class _DashboardState extends ConsumerState<Dashboard> {
  @override void initState() { super.initState(); WidgetsBinding.instance.addPostFrameCallback((_) => _sync()); }
  Future<void> _sync() async { final tasks = await ref.read(storeProvider).all(); await publish(tasks); if (mounted) ref.invalidate(tasksProvider); }
  Future<void> _addOrEdit({FlowTask? task}) async {
    final c = TextEditingController(text: task?.title ?? '');
    final title = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      title: Text(task == null ? 'New task' : 'Edit task'),
      content: TextField(controller: c, autofocus: true, maxLength: 100, decoration: const InputDecoration(hintText: 'What do you want to do?')),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('Save'))]));
    if (title == null || title.trim().isEmpty) return;
    if (task == null) { await ref.read(storeProvider).add(title); } else { await ref.read(storeProvider).update(task, title); }
    await _sync();
  }
  @override Widget build(BuildContext context) {
    final asyncTasks = ref.watch(tasksProvider);
    return Scaffold(
      appBar: AppBar(title: const Row(children: [Icon(Icons.blur_on_rounded, color: accent, size: 30), SizedBox(width: 8), Text('flow', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: -1))]), actions: [IconButton(tooltip: 'Wallpaper preview', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WallpaperPreview())), icon: const Icon(Icons.wallpaper_rounded))]),
      floatingActionButton: FloatingActionButton.extended(onPressed: () => _addOrEdit(), icon: const Icon(Icons.add), label: const Text('Add task')),
      body: asyncTasks.when(loading: () => const Center(child: CircularProgressIndicator()), error: (e, st) => Center(child: Text('Could not load tasks: $e')), data: (tasks) {
        final done = tasks.where((t) => t.done).length; final s = stateFor(done, tasks.length); final pct = tasks.isEmpty ? 0.0 : done / tasks.length;
        return ListView(padding: const EdgeInsets.fromLTRB(20, 12, 20, 100), children: [
          Text(DateFormat('EEEE, d MMMM').format(DateTime.now()).toUpperCase(), style: const TextStyle(color: Colors.white54, letterSpacing: 1.8, fontSize: 11, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10), const Text('Make today\\ncount.', style: TextStyle(fontSize: 38, height: 1.05, fontWeight: FontWeight.w800, letterSpacing: -1.5)),
          const SizedBox(height: 24),
          Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(24), border: Border.all(color: colorFor(s).withValues(alpha: .35))),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Container(width: 10, height: 10, decoration: BoxDecoration(color: colorFor(s), shape: BoxShape.circle)), const SizedBox(width: 8), Text(s.name.toUpperCase(), style: TextStyle(color: colorFor(s), fontWeight: FontWeight.w800, letterSpacing: 1.5, fontSize: 12)), const Spacer(), Text('${(pct*100).round()}%', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800))]),
              const SizedBox(height: 14), ClipRRect(borderRadius: BorderRadius.circular(8), child: LinearProgressIndicator(value: pct, minHeight: 8, backgroundColor: Colors.white10, color: colorFor(s))),
              const SizedBox(height: 12), Text('$done OF ${tasks.length} TASKS COMPLETED', style: const TextStyle(color: Colors.white60, fontSize: 11, letterSpacing: 1.3, fontWeight: FontWeight.w700)),
            ])),
          const SizedBox(height: 26),
          Row(children: [const Text("Today's tasks", style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), const Spacer(), Text('${tasks.length} total', style: const TextStyle(color: Colors.white54))]),
          const SizedBox(height: 12),
          if (tasks.isEmpty) Container(padding: const EdgeInsets.all(24), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(20)), child: const Column(children: [Icon(Icons.checklist_rounded, size: 36, color: Colors.white38), SizedBox(height: 10), Text('A clear page.', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)), SizedBox(height: 4), Text('Add a task and watch your wallpaper come to life.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54))]))
          else ...tasks.map((t) => Container(margin: const EdgeInsets.only(bottom: 9), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)), child: ListTile(
            leading: Checkbox(value: t.done, activeColor: accent, onChanged: (_) async { await ref.read(storeProvider).toggle(t); await _sync(); }),
            title: Text(t.title, style: TextStyle(decoration: t.done ? TextDecoration.lineThrough : null, color: t.done ? Colors.white54 : Colors.white, fontWeight: FontWeight.w600)),
            trailing: PopupMenuButton<String>(onSelected: (v) async { if (v == 'edit') await _addOrEdit(task: t); if (v == 'delete') { final yes = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: const Text('Delete task?'), content: Text('Remove “${t.title}”?'), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete'))])); if (yes == true) { await ref.read(storeProvider).delete(t); await _sync(); } } }, itemBuilder: (_) => const [PopupMenuItem(value: 'edit', child: Text('Edit')), PopupMenuItem(value: 'delete', child: Text('Delete'))]),
          ))),
          const SizedBox(height: 18),
          OutlinedButton.icon(onPressed: () async { try { final result = await bridge.invokeMethod<bool>('openWallpaperPicker'); if (result != true && context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Choose Flow in Android wallpaper settings to finish setup.'))); } on PlatformException { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Wallpaper setup is available on Android only.'))); } }, icon: const Icon(Icons.wallpaper_rounded), label: const Text('Set live wallpaper'), style: OutlinedButton.styleFrom(padding: const EdgeInsets.all(16))),
          const SizedBox(height: 8), const Text('Your wallpaper updates automatically when tasks change.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white38, fontSize: 12)),
        ]);
      }),
    );
  }
}

class WallpaperPreview extends ConsumerWidget {
  const WallpaperPreview({super.key});
  @override Widget build(BuildContext context, WidgetRef ref) => Scaffold(appBar: AppBar(title: const Text('Wallpaper preview')), body: ref.watch(tasksProvider).when(
    loading: () => const Center(child: CircularProgressIndicator()), error: (_, __) => const SizedBox(), data: (tasks) {
      final done = tasks.where((t) => t.done).length; final s = stateFor(done, tasks.length);
      return Container(width: double.infinity, margin: const EdgeInsets.all(18), padding: const EdgeInsets.all(24), decoration: BoxDecoration(color: const Color(0xFF111318), borderRadius: BorderRadius.circular(30), border: Border.all(color: Colors.white12)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SizedBox(height: 30), Center(child: Column(children: [Text(DateFormat('HH:mm').format(DateTime.now()), style: const TextStyle(fontSize: 58, fontWeight: FontWeight.w300)), Text(DateFormat('EEEE, d MMMM').format(DateTime.now()), style: const TextStyle(color: Colors.white70))])),
        const Spacer(), Text('FLOW / DAILY FOCUS', style: TextStyle(color: colorFor(s), letterSpacing: 2, fontSize: 11, fontWeight: FontWeight.bold)), const SizedBox(height: 10), Text('$done OF ${tasks.length} TASKS', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        const SizedBox(height: 14), ...tasks.take(6).map((t) => Padding(padding: const EdgeInsets.symmetric(vertical: 7), child: Row(children: [Icon(t.done ? Icons.check_box_rounded : Icons.check_box_outline_blank_rounded, color: t.done ? colorFor(s) : Colors.white54), const SizedBox(width: 10), Expanded(child: Text(t.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(decoration: t.done ? TextDecoration.lineThrough : null)))]))),
        if (tasks.length > 6) Text('+${tasks.length-6} more', style: const TextStyle(color: Colors.white54)), const Spacer(), Text(s == FlowState.green ? 'YOU SHOWED UP. WELL DONE.' : s == FlowState.neutral ? 'ADD A TASK. START SMALL.' : 'ONE THING AT A TIME.', style: TextStyle(color: colorFor(s), fontWeight: FontWeight.bold, letterSpacing: 1.2)), const SizedBox(height: 30)
      ]);
    }));
}

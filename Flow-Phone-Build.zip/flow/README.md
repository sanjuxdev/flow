# Flow — Flutter Task Tracker + Android Live Wallpaper

Flow is a Flutter Android-first task tracker with a native Kotlin `WallpaperService`. The wallpaper reads a durable JSON snapshot from app-private storage and renders it with Android Canvas; it does not require a Flutter activity or Dart isolate to remain running.

## Current implementation

- Flutter Material 3 task dashboard with create, edit, delete and completion toggles.
- SQLite persistence via sqflite; today's tasks are scoped by local date.
- Deterministic progress mapping: empty = NEUTRAL; incomplete under 34% = RED; incomplete at/above 34% = YELLOW; all complete = GREEN.
- Versioned JSON snapshot with revision, local date, task IDs/titles/completion, counts, percentage, state, timestamp.
- Kotlin platform channel writes snapshots atomically to `filesDir/flow-wallpaper.json`.
- Native WallpaperService reads snapshot on engine creation/visibility and receives in-process update notifications; multiple engine instances are supported.
- Canvas wallpaper renderer with clock, date, state, progress, checklist, and overflow indicator.
- System wallpaper picker integration and Flutter preview screen.
- Unit tests for progress boundaries.

## Build requirements

Install Flutter stable, Android Studio/Android SDK (API 35), and a compatible JDK (17 recommended). This sandbox did not include Flutter, Dart, Gradle, or an Android SDK, so an APK could not be compiled or device-tested here.

```bash
flutter doctor
flutter pub get
dart format lib test
flutter analyze
flutter test
flutter build apk --debug
```

Expected APK path after a successful build: `build/app/outputs/flutter-apk/app-debug.apk`.

## Install and configure

1. Build the debug APK and install it on an Android device.
2. Open Flow and create tasks.
3. Tap **Set live wallpaper**.
4. Select Flow in Android's system wallpaper picker and confirm the destination offered by the device (home screen, lock screen, or both, depending on OEM/Android version).
5. Toggle tasks in Flow. The saved snapshot is published to native storage and active wallpaper engines redraw.

## Snapshot contract (schema version 1)

```json
{
  "schemaVersion": 1,
  "revision": 1791840000000000,
  "localDate": "2026-10-12",
  "tasks": [{"id":"1","title":"Study","completed":false}],
  "completedCount": 0,
  "totalCount": 1,
  "completionPercent": 0,
  "colorState": "red",
  "updatedAt": "2026-10-12T18:00:00.000"
}
```

The database is the task source of truth. The snapshot is a derived rendering contract. Native parsing validates schema and verifies that its colour state agrees with task completion. Writes use Android `AtomicFile` and fsync before publication. If a malformed snapshot is encountered, the engine retains its last valid in-memory snapshot.

## Known limitations / verification status

- This source bundle has not been compiled in this environment; dependency/plugin compatibility and Android build issues remain unverified.
- The native service is implemented, but physical lock-screen behaviour has not been tested on a device.
- Task history screen, categories/priorities/due times, drag reordering UI, onboarding/settings screens, configurable reset time, and broader integration tests are not yet implemented.
- Tasks are date-scoped; previous-day rows are retained in SQLite, but historical summaries are not yet exposed in UI.
- Platform lock-screen destination depends on Android version and device manufacturer.
